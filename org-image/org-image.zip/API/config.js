module.exports = {
	//图片服务器地址
	redImgPath:"http://192.168.0.103:8080/",
	//默认错误图片地址
	defautlErrorImage:'/static/defautl-error.png'
}
